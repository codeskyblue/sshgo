# Hook for http://pypi.python.org/pypi/h5py/
# Author: dhyams
# Date: 2011-10-14
# Ticket: #437

hiddenimports = ['_proxy','utils','defs']
