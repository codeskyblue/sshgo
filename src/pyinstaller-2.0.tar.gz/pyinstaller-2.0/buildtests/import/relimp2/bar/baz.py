def say_hello_please():
    print "Hello World!"
