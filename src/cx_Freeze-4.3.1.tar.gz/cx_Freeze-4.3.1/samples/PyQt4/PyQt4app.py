import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

app = QApplication(sys.argv)
form = QDialog()
form.show()
app.exec_()

